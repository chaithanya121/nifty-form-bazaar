
import FormBuilder from "@/components/FormBuilder";

const Index = () => {
  return <FormBuilder />;
};

export default Index;
